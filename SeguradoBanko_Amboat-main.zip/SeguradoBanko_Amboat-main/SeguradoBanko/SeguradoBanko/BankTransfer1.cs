﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeguradoBanko
{
    public partial class BankTransfer1 : Form
    {
        private BankAccount account;

        public BankTransfer1(BankAccount account)
        {
            InitializeComponent();
            this.account = account;
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (account.BankTransferMethod(cmbPartner.Text, txtTransAccountName.Text, txtTransAccountNumber.Text, Convert.ToInt32(txtTransAmount.Text)))
            {
                MessageBox.Show($"Transaction Successful!\n\nAccount Holder: {account.Fullname}\nPartner Bank: {cmbPartner.Text}\nSent To: {txtTransAccountName.Text}\nAmount: ₱{txtTransAmount.Text}\nNew Balance: ₱{account.Balance}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                cmbPartner.SelectedIndex = -1;
                txtTransAccountName.Clear();
                txtTransAccountNumber.Clear();
                txtTransAmount.Clear();
            }
        }

        private void guna2PictureBox4_Click(object sender, EventArgs e)
        {
            History history = new History(account);
            history.Show();
            this.Hide();
        }


        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {
            HomeScreen home = new HomeScreen(account);
            home.Show();
            this.Hide();
        }

        private void guna2PictureBox2_Click(object sender, EventArgs e)
        {
            PayBills payBills = new PayBills(account);
            payBills.Show();
            this.Hide();
        }

        private void guna2PictureBox3_Click(object sender, EventArgs e)
        {
            BankTransfer transfer = new BankTransfer(account);
            transfer.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            BankTransfer banktrans = new BankTransfer(account);
            banktrans.Show();
            this.Hide();
        }

        private void NavigateToBankTransfer1()
        {
            BankTransfer1 transferForm = new BankTransfer1(account); // Pass the existing account
            transferForm.Show();
            this.Hide();
        }
    }
}
