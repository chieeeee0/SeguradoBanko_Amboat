﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeguradoBanko
{
    public partial class History : Form
    {
        private BankAccount account;

        public History(BankAccount account)
        {
            InitializeComponent();
            this.account = account;
            this.Load += new EventHandler(History_Load); // Ensure the Load event is linked
        }

        private void History_Load(object sender, EventArgs e)
        {
            richTextBoxTransactions.Clear();

            // Ensure account and Transactions are not null or empty
            if (account == null || account.Transactions == null || !account.Transactions.Any())
            {
                MessageBox.Show("No transactions to display!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // Loop through each transaction and display it in the RichTextBox
            foreach (var transaction in account.Transactions)
            {
                // Format the transaction details with newlines for better multi-line support
                string transactionDisplay = $"Date: {transaction.Date:yyyy-MM-dd HH:mm:ss}\n" +
                                            $"Description: {transaction.Description}\n" +
                                            $"Amount: ₱{transaction.Amount:F2}\n\n"; // Add extra newline for spacing

                // Append formatted string to RichTextBox
                richTextBoxTransactions.AppendText(transactionDisplay);
            }
        }






        private void pictureBox1_Click(object sender, EventArgs e)
        {
            HomeScreen homeScreen = new HomeScreen(account);
            homeScreen.Show();
            this.Hide();
        }

    }
}

